/*
 * Copyright (c) 2018, ARM Limited and Contributors. All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#ifndef __WA_CVE_2017_5715_H__
#define __WA_CVE_2017_5715_H__

int check_wa_cve_2017_5715(void);

#endif /* __WA_CVE_2017_5715_H__ */
