/*
 * Copyright (c) 2015-2019, ARM Limited and Contributors. All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#ifndef TBBR_IMG_DEF_H
#define TBBR_IMG_DEF_H

#include <export/common/tbbr/tbbr_img_def_exp.h>

#endif /* TBBR_IMG_DEF_H */
