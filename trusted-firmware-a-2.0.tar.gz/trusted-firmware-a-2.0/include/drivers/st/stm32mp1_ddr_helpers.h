/*
 * Copyright (c) 2017-2018, STMicroelectronics - All Rights Reserved
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#ifndef __STM32MP1_DDR_HELPERS_H__
#define __STM32MP1_DDR_HELPERS_H__

void ddr_enable_clock(void);

#endif /* __STM32MP1_DDR_HELPERS_H__ */
