/*
 * Copyright (c) 2015-2018, STMicroelectronics - All Rights Reserved
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#ifndef _STM32MP1_RAM_H
#define _STM32MP1_RAM_H

int stm32mp1_ddr_probe(void);

#endif /* _STM32MP1_RAM_H */
