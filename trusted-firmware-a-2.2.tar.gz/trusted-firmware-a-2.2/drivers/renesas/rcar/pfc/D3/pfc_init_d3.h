/*
 * Copyright (c) 2017, Renesas Electronics Corporation. All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#ifndef PFC_INIT_D3_H
#define PFC_INIT_D3_H

void pfc_init_d3(void);

#endif	/* PFC_INIT_D3_H */
